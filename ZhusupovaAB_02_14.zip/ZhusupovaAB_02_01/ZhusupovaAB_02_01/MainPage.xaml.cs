﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ZhusupovaAB_02_01
{
    public partial class MainPage :ContentPage
    {
        public MainPage ()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
        }

        private async void Perehod (object sender, EventArgs e)
        {
            string login = "ects";
            string password = "ects2023";
            if (!String.IsNullOrEmpty(LoginForm.Text) && !String.IsNullOrEmpty(PasswordForm.Text))
            {
                if(LoginForm.Text==login && PasswordForm.Text==password)
                {
                    await Navigation.PushAsync(new SecondActivity());
                } 
            } 
            else
            {
                    await DisplayAlert("Ошибка", "Введеные данные неверные", "Попробуйте снова");
            }
            
        }
    }
}
