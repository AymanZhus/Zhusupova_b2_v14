﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ZhusupovaAB_02_01
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ThirdActivity :ContentPage
    {
        public ThirdActivity ()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
        }
    }
}